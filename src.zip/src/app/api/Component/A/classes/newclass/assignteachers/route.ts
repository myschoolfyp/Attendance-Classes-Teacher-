import { NextResponse } from "next/server";
import mongoose from "mongoose";
import ClassModel from "@/models/Class";
import TeacherModel from "@/models/Teacher";

// Connect to MongoDB
const connectToDatabase = async () => {
  if (mongoose.connection.readyState === 0) {
    await mongoose.connect(process.env.MONGODB_URI!);
  }
};

// route.ts - Fix duplicate fetchTeachers handler
export async function GET(request: Request) {
  try {
    await connectToDatabase();
    const { searchParams } = new URL(request.url);
    const action = searchParams.get("action");
    const department = searchParams.get("department");

    if (action === "fetchClasses") {
      const classes = await ClassModel.find({}, { students: 0 })
        .populate('teachers.teacher', 'firstName lastName')
        .exec();
      return NextResponse.json(classes);
    }

    if (action === "fetchTeachers" && department) {
      const teachers = await TeacherModel.find({ department })
        .select("firstName lastName department cnic")
        .exec();
      return NextResponse.json(teachers);
    }

    return NextResponse.json(
      { error: "Invalid action or missing parameters" },
      { status: 400 }
    );
  } catch (error) {
    console.error("Error in API route:", error);
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 }
    );
  }
}

// route.ts - Update POST handler
export async function POST(request: Request) {
  try {
    await connectToDatabase();
    const { className, teachers } = await request.json();

    // Validate input
    if (!className || !teachers || !Array.isArray(teachers)) {
      return NextResponse.json({ error: "Invalid input data" }, { status: 400 });
    }

    // Update class document
    const updatedClass = await ClassModel.findOneAndUpdate(
      { className },
      { $set: { teachers } },
      { new: true }
    );

    if (!updatedClass) {
      return NextResponse.json({ error: "Class not found" }, { status: 404 });
    }

    // Update teacher documents with proper ID handling
    const updateResults = await Promise.all(
      teachers.map(async (teachers) => {
        try {
          // Validate teacher ID format
          if (!mongoose.Types.ObjectId.isValid(teachers.teacherId)) {
            console.error(`Invalid Teacher ID format: ${teachers.teacherId}`);
            return { success: false, teacherId: teachers.teacherId };
          }

          const teacherObjectId = new mongoose.Types.ObjectId(teachers.teacherId);

          // Verify teacher exists
          const teacherExists = await TeacherModel.exists({ _id: teacherObjectId });
          if (!teacherExists) {
            console.error(`Teacher document not found: ${teachers.teacherId}`);
            return { success: false, teacherId: teachers.teacherId };
          }

          // Update teacher assignments
          const updatedTeacher = await TeacherModel.findByIdAndUpdate(
            teacherObjectId,
            {
              $addToSet: {
                assignments: {
                  class: className,
                  course: teachers.course
                }
              }
            },
            { new: true }
          );

          return { success: true, teacherId: teachers.teacherId };
        } catch (error) {
          console.error(`Error updating teacher ${teachers.teacherId}:`, error);
          return { success: false, teacherId: teachers.teacherId };
        }
      })
    );

    // Check for failed updates
    const failedUpdates = updateResults.filter(result => !result.success);
    if (failedUpdates.length > 0) {
      console.error('Failed teacher updates:', failedUpdates);
    }

    return NextResponse.json({
      success: true,
      message: "Teachers assigned successfully!",
      updatedClass,
      failedUpdates
    });
  } catch (error) {
    console.error("Error in POST handler:", error);
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}